
       $(document).ready(function() {
            $('#login').on('submit', function(event) {
                event.preventDefault(); 
                
                let valid = true;
                const email = $('#user').val().trim();
                const password = $('#pass').val().trim();
                $('#message').text(''); 
                $('#user, #pass').removeClass('error'); 

                if (email === "" || password === "") {
                    $('#message').text("Please fill in all the fields.");
                    if (email === "") {
                        $('#user').addClass('error'); 
                    }
                    if (password === "") {
                        $('#pass').addClass('error'); 
                    }
                    valid = false;
                } else if (!/^[^\s@]+@(gmail\.com|yahoo\.com|ymail\.com|outlook\.com|hotmail\.com)$/.test(email)) {
                    $('#user').addClass('error'); 
                    $('#message').text("Please enter a valid email address."); 
                    valid = false;
                } else if (password.length <= 8) {
                    $('#pass').addClass('error'); 
                    $('#message').text("Password must be longer than 8 characters."); 
                    valid = false;
                } else if (!/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])(?!.*\s)[A-Za-z\d!@#$%^&*]{8,}$/.test(password)) {
                    $('#pass').addClass('error');
                    $('#message').text("Password must contain at least one uppercase letter, one special character, and one digit."); 
                    valid = false; 
                }

                if (valid) {
                    $.ajax({
                        url: 'login',
                        type: 'POST',
                        contentType: 'application/x-www-form-urlencoded',
                        data: {
                            email: email,
                            password: password
                        },
                        success: function(response) {
                            console.log(response);
                            window.location.href = 'sucess'; 
                        },
                        error: function(xhr, status, error) {
                            console.error('Error: ' + xhr.statusText);
                            alert('Error: ' + xhr.statusText);
                        }
                    });
                }
            });
        });
  

			/*var xhr = new XMLHttpRequest();
			xhr.open("POST", "login", true);
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

			xhr.onreadystatechange = function() {
			    if (xhr.readyState === XMLHttpRequest.DONE) {
			        if (xhr.status === 200) {
			            console.log(xhr.responseText); // Handle successful response
			            window.location.href = 'sucess'; // Redirect to sucess.jsp
			        } else {
			            console.error('Error: ' + xhr.statusText); // Handle error
			            alert('Error: ' + xhr.statusText);
			        }
			    }
			};

			xhr.send(new URLSearchParams({
			    email: email,
			    password: password
			}).toString());
		    }*/
		
		

			
			/*fetch("login", {
						                method: 'POST',
						                headers: {
						                    'Content-Type': 'application/x-www-form-urlencoded'
						                },
						                body: new URLSearchParams({
						                    email: email,
						                    password: password
						                })
						            })
						            .then(response => {
						                if (!response.ok) {
						                    throw new Error('Network response was not ok: ' + response.statusText);
						                }
						                return response.text(); // or response.json
										() if your controller returns JSON
						            })
						            .then(data => {
						                window.location.href = 'sucess'; // Redirect to sucess.jsp
						            })
						            .catch(error => {
						                console.error('There was a problem with the fetch operation:', error);
						                alert('Error: ' + error.message); // Alert the user
						            });
									}
									});*/	