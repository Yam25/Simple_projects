function validateName(name) {
    const namePattern = /^[A-Za-z\s]+$/; // Only letters and spaces allowed
    return namePattern.test(name) && name.length > 0;
}

function validatePhoneNumber(phone) {
    const phonePattern = /^\d{10}$/; 
    return phonePattern.test(phone);
}

function validateDOB(dob) {
    const date = new Date(dob);
    const today = new Date();
    return date < today; 
}

function validateAddress(address) {
    return address.trim().length > 0; 
}

function validateDate(date) {
    return date !== ""; 
}

function validateForm() {
    const firstName = document.getElementById("firstName");
    const lastName = document.getElementById("lastName");
    const phoneNumber = document.getElementById("phoneNumber");
    const dob = document.getElementById("dob");
    const address = document.getElementById("address");
    const course = document.getElementById("course");
    const gender = document.getElementById("gender");
    const enrollmentDate = document.getElementById("enrollmentDate");
    const graduationDate = document.getElementById("graduationDate");

    let isValid = true;

    

    if (!validateName(firstName.value)) {
        firstName.style.border = "1px solid red";
        isValid = false;
    }
    if (!validateName(lastName.value)) {
        lastName.style.border = "1px solid red";
        isValid = false;
    }
    if (!validatePhoneNumber(phoneNumber.value)) {
        phoneNumber.style.border = "1px solid red";
        isValid = false;
    }
    if (!validateDOB(dob.value)) {
        dob.style.border = "1px solid red";
        isValid = false;
    }
    if (!validateAddress(address.value)) {
        address.style.border = "1px solid red";
        isValid = false;
    }
    if (course.value === "") {
        course.style.border = "1px solid red";
        isValid = false;
    }
    if (gender.value === "") {
        gender.style.border = "1px solid red";
        isValid = false;
    }
    if (!validateDate(enrollmentDate.value)) {
        enrollmentDate.style.border = "1px solid red";
        isValid = false;
    }
    if (!validateDate(graduationDate.value)) {
        graduationDate.style.border = "1px solid red";
        isValid = false;
    }

    return isValid;
}

document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault(); 
    if (validateForm()) {

        console.log("Form is valid and ready for submission.");
		document.getElementById('form').addEventListener('submit', function(event) {
		    event.preventDefault(); // Prevent the default form submission

		    if (validateForm()) {
		        const formData = new URLSearchParams(new FormData(this)).toString(); // Create URL-encoded string

		        const xhr = new XMLHttpRequest();
		        xhr.open("POST", "submitStudentForm", true);
		        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); // Set content type

		        xhr.onreadystatechange = function () {
		            if (xhr.readyState === XMLHttpRequest.DONE) {
		                if (xhr.status === 200) {
		                    console.log('Success:', xhr.responseText);
		                    window.location.href = "success"; // Handle success (e.g., show a success message or redirect)
		                } else {
		                    console.error('Error:', xhr.statusText);
		                    // Handle error (e.g., show an error message)
		                }
		            }
		        };

		        xhr.send(formData); // Send the URL-encoded string
		    } else {
		        console.log("Form validation failed.");
		    }
		});

		
    } else {
        console.log("Form validation failed.");
    }
});
