package com.student.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.student.Model.User;
import com.student.Service.Student_service;


@Controller
public class Student_Controller {

	@GetMapping("/")
    public String home() {
        return "index"; 
    }
	@GetMapping("/sucess") 
    public String success() {
        return "sucess"; 
    }
	
	
	
	
	
	 @Autowired
	    private Student_service userService; 
        
	    
	    @PostMapping("/login")
	    public String loginUser(@RequestParam String email, @RequestParam String password) {
	        System.out.println("recieved data");
	        User user = new User(email, password);
	        userService.save(user); 
	        return "redirect:/sucess"; 
	    }
}
