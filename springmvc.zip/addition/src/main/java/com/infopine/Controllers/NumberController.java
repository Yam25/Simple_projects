package com.infopine.Controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infopine.Model.AddNumber;
import com.infopine.Service.NumberService;

@Controller
public class NumberController {
	@Autowired
    private AddNumber add;
    @Autowired
	private NumberService ser;
    @RequestMapping("/add")
	public void add(HttpServletRequest req, HttpServletResponse res) {
		int a = Integer.parseInt(req.getParameter("firstName"));
		int b = Integer.parseInt(req.getParameter("secondName"));
		int results = a+b;
		add.setFirstNum(a);
		add.setSecondNum(b);
		add.setResults(results);
		ser.addNumber(add);
	}
}
