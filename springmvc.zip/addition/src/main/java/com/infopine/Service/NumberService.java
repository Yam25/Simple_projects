package com.infopine.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infopine.Model.AddNumber;
import com.infopine.Repository.NumberRepository;

@Service
public class NumberService {
	@Autowired
    private NumberRepository repo;
	
	public void  addNumber( AddNumber add) {
		repo.addnum(add);
	}
}
