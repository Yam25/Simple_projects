package com.infopine.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class AddNumber {
 @Id
 private int firstNum;
 private int secondNum;
 private int results;
public int getFirstNum() {
	return firstNum;
}
public void setFirstNum(int firstNum) {
	this.firstNum = firstNum;
}
public int getSecondNum() {
	return secondNum;
}
public void setSecondNum(int secondNum) {
	this.secondNum = secondNum;
}
public int getResults() {
	return results;
}
public void setResults(int results) {
	this.results = results;
}
}
