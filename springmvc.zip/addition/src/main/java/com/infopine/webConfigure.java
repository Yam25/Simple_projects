package com.infopine;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class webConfigure extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {NumberConfigure.class};
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"}; //this for mapping any requests
	}

	
}
