package com.infopine1.springAnno;

public interface MobileProcessor {

	void process();
}
