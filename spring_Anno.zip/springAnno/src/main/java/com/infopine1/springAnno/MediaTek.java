package com.infopine1.springAnno;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/*
 * As this class gives implementation for same interface as Snapdragon class, it creates confusion so if we write @Primary , this class implementation used over Snapdragon class
 */
@Component
@Primary 
public class MediaTek implements MobileProcessor {
	
public void process() {
	System.out.println("2nd best CPU");
}
}
