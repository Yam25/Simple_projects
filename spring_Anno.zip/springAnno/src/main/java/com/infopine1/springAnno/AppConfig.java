package com.infopine1.springAnno;

/*import org.springframework.context.annotation.Bean;*/
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration //used to indicate that this class is for configuration purposes
@ComponentScan(basePackages = "com.infopine1.springAnno") // use this auto config instead of creating bean for every class object
//but you need to add @Component to all the classes that you need objects of. (use "," if multiple packages are there.
public class AppConfig {
	/*
	 * @Bean //this method returns bean to App.java public Samsung getPhone() {
	 * return new Samsung(); }
	 * 
	 * @Bean //for every object needed its needs to created here public
	 * MobileProcessor getCpu() { return new Snapdragon(); }
	 */
}
