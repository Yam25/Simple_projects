package com.infopine1.springAnno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Annotation based Dependency Injection 
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class); //mapping context to configuration class
       samsung s7 = context.getBean(samsung.class); // getting the bean of samsung.class, cuz the config class returns the object of the samsung class as bean.
       s7.config();
    }
}
