package com.infopine1.Yamini;

import org.springframework.stereotype.Component;

@Component
public class bike implements vehicle{
public void drive() {
	System.out.println("bike is riding");
}
}
