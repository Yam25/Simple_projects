package com.infopine1.Yamini;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //this creates a bean with id as same as the class name
public class car implements vehicle {
	@Autowired
	private tyre t;
	
public tyre getT() {
		return t;
	}

	public void setT(tyre t) {
		this.t = t;
	}

public void drive()
   {
	System.out.println("car is driving "+ t);
	}
}
