package com.infopine1.Yamini;

public interface vehicle {
void drive();
}
