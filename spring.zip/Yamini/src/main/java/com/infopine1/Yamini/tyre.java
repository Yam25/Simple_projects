package com.infopine1.Yamini;

import org.springframework.stereotype.Component;

@Component
public class tyre {
	
	private String brands;
	

	

	/*
	 * public tyre(String brands) { super(); this.brands = brands; }
	 */
	public String getBrands() {
		return brands;
	}

	/*
	 * public void setBrands(String brands) { this.brands = brands; }
	 */

	@Override
	public String toString() {
		return "its working"; /* "tyre [brands=" + brands + "]" */
	}
	

}
