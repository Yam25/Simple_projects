package com.infopine1.Yamini;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Spring core
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//we are not changing the source code,we are changing the xml file
       //BeanFactory for small applications. use ApplicationContext for web applications these two interfaces have getBean()
    	ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml"); //it will go to xml file and do all the configuration,
		/* vehicle obj = (vehicle) context.getBean("bike"); *///will achieve dependency injection, obj should be independent of car and bike classes
		/* obj.drive(); */
       //((ClassPathXmlApplicationContext) context).close();
		/*
		 * 
		 * 
		 * tyre ob = (tyre) context.getBean("tyre"); System.out.println(ob);
		 */
    	 car obj = (car) context.getBean("car");
    	 obj.drive();
    	}
}
