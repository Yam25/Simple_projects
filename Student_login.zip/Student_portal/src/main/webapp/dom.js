document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("login");
    const button = document.getElementById("submit");
    const emailInput = document.getElementById("user");
    const passwordInput = document.getElementById("pass");

    button.addEventListener("click", function(event) {
        let valid = true;
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (email === "" || password === "") {
            alert("Please fill in all the fields.");
            valid = false;
        } else if (!/^[^\s@]+@(gmail\.com|yahoo\.com|ymail\.com|outlook\.com|hotmail\.com)$/.test(email)) {
            alert("Please enter a valid email address.");
            valid = false;
        } else if (password.length <= 8) {
            alert("Password must be longer than 8 characters.");
            valid = false;
        }

        if (!valid) {
            event.preventDefault();
        } else {
            alert("Form is valid! Submitting...");
        }
    });
});
