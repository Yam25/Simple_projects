package com.infopine.Repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.infopine.Model.AddNumber;

@Repository
public class NumberRepository {

	public void addnum(AddNumber add) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(AddNumber.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		session.save(add);
		t.commit();
		session.close();
	}

	public void subnum(AddNumber add) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(AddNumber.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		session.save(add);
		t.commit();
		session.close();
		
	}

}
