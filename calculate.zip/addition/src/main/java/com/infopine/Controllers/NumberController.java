package com.infopine.Controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infopine.Model.AddNumber;
import com.infopine.Service.NumberService;

@Controller
public class NumberController {
	@Autowired
    private AddNumber add;
    @Autowired
	private NumberService ser;
    @RequestMapping("/myServ")
	public void add(HttpServletRequest req, HttpServletResponse res) {
		int a = Integer.parseInt(req.getParameter("firstName"));
		int b = Integer.parseInt(req.getParameter("secondName"));
		String val = req.getParameter("ops");
		if(val.equals("add")) {
		int results = a+b;
		add.setFirstNum(a);
		add.setSecondNum(b);
		add.setResults(results);
		ser.addNumber(add);
		}
		else if(val.equals("sub")){
   		int results1 = a-b;
   		add.setFirstNum(a);
   		add.setSecondNum(b);
   		add.setResults(results1);
   		ser.subNumber(add);
   	}
}
}