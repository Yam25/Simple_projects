package com.infopine.Repository;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.infopine.Model.Student_details;
@Repository
public class Student_Repository {
    //insert
	public void insert(Student_details sd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		session.save(sd);
		t.commit();
		System.out.println("Record added Successfully");
		session.close();
	}
    //delete
	public void delete(int id) {
		    Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
		    SessionFactory sf = cfg.buildSessionFactory();
		    Session session = sf.openSession();
		    Transaction t = session.beginTransaction();
		    
		    // Fetch the existing student record
		    
				Student_details sd = session.get(Student_details.class, id); 
				//System.out.println(sd.getName());
				if (sd != null) {
				    session.delete(sd);
				    t.commit();
				    System.out.println("Record deleted Successfully");
				    session.close();// Delete the record if found
				
			}
		}
	//update
	public void update(Student_details sd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();
       
        
			session.update(sd); // Update the record with new details
			t.commit();
			System.out.println("Record updated Successfully");
			session.close();
		
		}
	public List<Student_details> findAll() {
		
		  Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
		  SessionFactory sf = cfg.buildSessionFactory(); 
		  Session session = sf.openSession(); 
		  Transaction t = session.beginTransaction();
		  String hql = "FROM Student_details";
		  Query<Student_details> query = session.createQuery(hql);
		  List<Student_details> results = query.list();
		  t.commit();
		  session.close();
		  return results;
		  }
	}

			/*
			 * //display on console public void findAll() { Configuration cfg = new
			 * Configuration().configure().addAnnotatedClass(Student_details.class);
			 * SessionFactory sf = cfg.buildSessionFactory(); Session session =
			 * sf.openSession(); String hql = "FROM Student_details"; Query<Student_details>
			 * query = session.createQuery(hql, Student_details.class);
			 * List<Student_details> results = query.list(); for (int i = 0; i <
			 * results.size(); i++) { Student_details student = results.get(i);
			 * System.out.println("ID: " + student.getID() + ", Name: " +
			 * student.getName()+", Branch: "+student.getBranch()); } session.close(); }
			 */
	
		
	

