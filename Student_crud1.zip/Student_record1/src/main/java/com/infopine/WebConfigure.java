package com.infopine;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class WebConfigure extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
	
		return new Class[] {MainConfigure.class}; 
	}

	@Override
	protected String[] getServletMappings() {
		
		return new String[] {"/"}; //url pattern mapping for requests
	}
	

}
