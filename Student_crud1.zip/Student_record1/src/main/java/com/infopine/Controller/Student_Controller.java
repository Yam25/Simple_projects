package com.infopine.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infopine.Model.Student_details;
import com.infopine.Service.Student_Service;

@Controller
public class Student_Controller {
	
	
	 @Autowired 
	 private Student_details sd;
	 
	 

	@Autowired
	private Student_Service ss;
	
	
	/*
	 * while navigating or using href in jsp file always use /names not .jsp file name for getMapping.
       if you use postMapping make sure you either redirect it to getMapping or use .jsp file name in href while linking it in jsp file.
       
	 * @GetMapping("/") // For the index page public String showForm(Model model) {
	 * return "index"; // This returns index.jsp }
	 * 
	 * @GetMapping("/delete") // For the delete page public String
	 * showDeletePage(Model model) { return "delete"; // Adjust accordingly }
	 * 
	 * @GetMapping("/students") // For viewing all students public String
	 * viewAllStudents(Model model) { // Logic to get students and add to model
	 * return "display"; // Adjust accordingly }
	 * 
	 * @GetMapping("/edit") // For the edit page public String showEditPage(Model
	 * model) { return "edit"; // Adjust accordingly }
	 */


@PostMapping("/submit")
public String insert(@RequestParam("id") int id, @RequestParam("name") String name, @RequestParam("branch") String branch, Model model) {
   
	        sd.setID(id);
	        sd.setName(name);
	        sd.setBranch(branch);
	        
	        ss.insert(sd);
	        
	        model.addAttribute("message", "Student added successfully!");
	       
	        return "message.jsp";// Resolve to Message.jsp
	        
	    }
@PostMapping("/delete") //delete
public String delete(@RequestParam("id") int id, Model model) {
	ss.delete(id);
	model.addAttribute("message", "Student deleted successfully!");
    return "Message.jsp";
}
@PostMapping("/update") //update
public String edit(@RequestParam("id") int id, @RequestParam("name") String newName, @RequestParam("branch") String newBranch, Model model) {
	sd.setID(id);
	sd.setName(newName);
	sd.setBranch(newBranch);
	ss.update(sd);
	model.addAttribute("message", "Student updated successfully!");
    return "Message.jsp"; 
}
@GetMapping("/students") 
public String findAll( Model model)
{
	
	    List<Student_details> students = ss.findAll();
	    System.out.println("Number of students fetched: " + (students != null ? students.size() : "null"));
	    model.addAttribute("students", students); // Use model to pass data
	   model.addAttribute("message", "Student records displayed successfully!");
	   return "display.jsp";
}
}
