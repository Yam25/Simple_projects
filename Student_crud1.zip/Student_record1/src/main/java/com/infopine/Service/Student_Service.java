package com.infopine.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infopine.Model.Student_details;
import com.infopine.Repository.Student_Repository;

@Service
public class Student_Service {
	@Autowired
	private Student_Repository repo;
public void insert(Student_details sd) {
	repo.insert(sd);
}

public void delete(int id) {   
	repo.delete(id);
}



public void update(Student_details sd) {
	        repo.update(sd); 
}

//display on console
public List<Student_details> findAll() {
   return repo.findAll();
    
} 
}
/*
 * public boolean delete(int id) { // Assuming you have a method to find a
 * student by ID Student_details student = studentRepository.findById(id); if
 * (student != null) { studentRepository.delete(student); return true; //
 * Deletion was successful } return false; // Record not found }
 */
