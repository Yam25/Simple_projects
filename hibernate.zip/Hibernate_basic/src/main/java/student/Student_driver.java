package student;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Student_driver {
public static void main(String[] args) {

	/*Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	Transaction t = s.beginTransaction();
	Student_details st = new Student_details();
	st.setRoll_no(104);
	st.setName("Yamini");
	s.save(st);
	t.commit();
	s.close();
	System.out.println("row inserted successfully!");
	updateTable(102);
	deleteTable(102);*/
	displayTable();
}

//updating the database referring with id column
public static void updateTable(int roll_no){
	Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	try {
	Transaction t = s.beginTransaction();
	Student_details st = s.get(Student_details.class, roll_no);
	if(st != null) {
		st.setName("Page");
		s.update(st);
		t.commit();
		System.out.println("Row updated successfully");
	}
	else {
		System.out.println("Student record  not found!");
	}
}catch(Exception e) {
		
	    e.printStackTrace();
	}
	finally {
		s.close();
	}
}

//deleting the existing record referring with id column
public static void deleteTable(int roll_no) {
	Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	try {
		Transaction t = s.beginTransaction();
		Student_details st = s.get(Student_details.class, roll_no);
		if(st != null) {
			s.delete(st);
			t.commit();
			System.out.println("Row deleted successfully");
		}
		else {
			System.out.println("Student record not found!");
		}
	}catch(Exception e) {
			
		    e.printStackTrace();
		}finally {
			s.close();
		}
	}

//displaying the whole table, method 1, it is most used method
//Displaying the whole table
public static void displayTable() {
 Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
 SessionFactory sf = cfg.buildSessionFactory();
 Session s = sf.openSession();
 
 try {
     // Create a query to select all Student_details records
     String hql = "FROM Student_details"; //using class name instead of table name
     Query<Student_details> query = s.createQuery(hql, Student_details.class);

     // Execute the query and get the results
     List<Student_details> results = query.list();

     // Iterate through the results and print each student's details
     for (int i = 0; i < results.size(); i++) {
         Student_details student = results.get(i); // Access the student at index i
         System.out.println("Roll No: " + student.getRoll_no() + ", Name: " + student.getName());
     }

 } catch (Exception e) {
     e.printStackTrace();
 } finally {
     s.close();
 }
}
}


