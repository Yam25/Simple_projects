document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("login");
    //const button = document.getElementById("submit");
    const emailInput = document.getElementById("user");
    const passwordInput = document.getElementById("pass");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); 
        let valid = true;
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

       
        emailInput.style.border = "";
        passwordInput.style.border = "";

        if (email === "" || password === "") {
			alert("Please fill in all the fields.");
			if(email === "")
			{
            emailInput.style.border = "1px solid red"; 
			}
            if(password === "")
			{
            passwordInput.style.border = "1px solid red"; 
			}
            
            valid = false;
        } else if (!/^[^\s@]+@(gmail\.com|yahoo\.com|ymail\.com|outlook\.com|hotmail\.com)$/.test(email)) {
            emailInput.style.border = "1px solid red"; 
            alert("Please enter a valid email address."); 
            valid = false;
        } else if (password.length <= 8) {
		   passwordInput.style.border = "1px solid red"; 
	       alert("Password must be longer than 8 characters."); 
		   valid = false;
	   } else if(!/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])(?=\S)\S.{8,}$/.test(password)){
			passwordInput.style.border = "1px solid red";
			alert("Password must contain atleast one Uppercase, Special Character and Digit."); 
			valid = false; 
		}

        if (valid) {
			fetch("login", {
			                method: 'POST',
			                headers: {
			                    'Content-Type': 'application/x-www-form-urlencoded'
			                },
			                body: new URLSearchParams({
			                    email: email,
			                    password: password
			                })
			            })
			            .then(response => {
			                if (!response.ok) {
			                    throw new Error('Network response was not ok: ' + response.statusText);
			                }
			                return response.text(); // or response.json() if your controller returns JSON
			            })
			            .then(data => {
			                console.log(data); // Handle successful response
			                window.location.href = 'sucess'; // Redirect to sucess.jsp
			            })
			            .catch(error => {
			                console.error('There was a problem with the fetch operation:', error);
			                alert('Error: ' + error.message); // Alert the user
			            });
						}
						});
					
});
