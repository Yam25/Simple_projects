package com.student.Repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;


import com.student.Model.User;

@Repository
public class Student_repo {

	public void save(User user) {{
			Configuration cfg = new Configuration().configure().addAnnotatedClass(User.class);
			SessionFactory sf = cfg.buildSessionFactory();
			Session session = sf.openSession();
			Transaction t = session.beginTransaction();

			try {

				session.save(user);
				t.commit();
				System.out.println("Record added successfully");
				 

			} catch (Exception e) {
				
				e.printStackTrace(); 
				
			} finally {
				if (session != null) {
					session.close();
					;
				}
			}
		}
		
	}

}
