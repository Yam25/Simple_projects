package com.student.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.Model.User;
import com.student.Repository.Student_repo;

@Service
public class Student_service {
	@Autowired
    private Student_repo userRepository; // Ensure you have this repository


	public void save(User user) {
		
		userRepository.save(user);
	}

}
