package com.student.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.Model.User;
import com.student.Service.Student_service;


@Controller
public class Student_Controller {

	@GetMapping("/")
    public String home() {
        return "index"; // This should match your JSP filename without the .jsp extension
    }
	@GetMapping("/sucess") // Add this method
    public String success() {
        return "sucess"; // This should match your success.jsp filename without the .jsp extension
    }
	
	 @Autowired
	    private Student_service userService; // Assuming you have a service layer

	    @PostMapping("/login")
	    public String loginUser(@RequestParam String email, @RequestParam String password, Model model) {
	        System.out.println("recieved data");
	        User user = new User(email, password);
	        userService.save(user); // Save to database
	        return "redirect:/sucess"; // Redirect to success page
	    }
}
