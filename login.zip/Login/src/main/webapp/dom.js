document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("login");
    const emailInput = document.getElementById("user");
    const passwordInput = document.getElementById("pass");

    form.addEventListener("click", function(event) {
        let valid = true;

        // Validate email
        const email = emailInput.value.trim();
        if (email === "") {
            alert("Email cannot be empty.");
            valid = false;
        } else {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                valid = false;
            }
        }

        // Validate password
        const password = passwordInput.value.trim();
        if (password === "") {
            alert("Password cannot be empty.");
            valid = false;
        } else if (password.length <= 8) {
            alert("Password must be longer than 8 characters.");
            valid = false;
        }

        // Prevent form submission if invalid
        if (!valid) {
            event.preventDefault();
        } else {
            alert("Form is valid! Submitting...");
        }
    });
});
