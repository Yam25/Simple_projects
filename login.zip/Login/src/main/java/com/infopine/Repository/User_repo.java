package com.infopine.Repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.infopine.Model.User;


@Repository
public class User_repo {

	public void fetch(User user) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction t = ss.beginTransaction();
		
		System.out.println("Connection is successful");
		
			ss.save(user);
			t.commit();
		
}
}
	
