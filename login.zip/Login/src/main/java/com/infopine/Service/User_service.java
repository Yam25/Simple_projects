package com.infopine.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infopine.Model.User;
import com.infopine.Repository.User_repo;

@Service
public class User_service {
    @Autowired
	private User_repo repo;
    
   public void fetch(User user) {
	   repo.fetch(user);
	  
    }
}
