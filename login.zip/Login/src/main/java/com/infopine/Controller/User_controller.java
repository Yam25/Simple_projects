package com.infopine.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infopine.Model.User;
import com.infopine.Service.User_service;

@RestController // Use @RestController for RESTful response
public class User_controller {

    @Autowired
    private User_service service;

    @PostMapping("/login")
    public ResponseEntity<String> fetch(@RequestBody User user) {
        // You may want to add additional validation or checks here
        service.fetch(user); // Save the user to the database
        return ResponseEntity.ok("User added successfully");
    }
}
