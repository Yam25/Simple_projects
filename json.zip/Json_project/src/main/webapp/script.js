// Function to load and display the JSON data


 async function loadMusicData() {
    try {
        const response = await fetch('music.json'); // Fetch the JSON file
        const data = await response.json(); // Parse the JSON data

        // Display the parsed object in the output area
        const output = document.getElementById('output');
        output.textContent = JSON.stringify(data, null, 2); // Pretty print JSON

        return data; // Return the data for later use
    } catch (error) {
        console.error('Error fetching the music data:', error);
    }
};

// Convert a JavaScript object back to JSON
function convertToJson() {
    const jsObject = {
        artist: {
            name: "Metro Boomin",
            birthYear: 1993,
            genres: ["Hip Hop", "Rap", "Trap"],
            albums: [
                {
                    title: "Not All Heroes Wear Capes",
                    year: 2018,
                    tracks: ["24 Savage", "Overdue", "No Complaints", "Space Cadet"]
                },
                {
                    title: "Savage Mode II",
                    year: 2020,
                    tracks: ["Mr. Right Now", "Runnin", "Glock in My Lap", "Said N Done"]
                },
                {
                    title: "Heroes & Villains",
                    year: 2022,
                    tracks: ["On Time", "Superhero", "Too Many Nights", "I Can’t Save You"]
                }
            ]
        }
    };
    const jsonString = JSON.stringify(jsObject, null, 2);
    document.getElementById('jsonOutput').textContent = jsonString; // Display the JSON string
}

// Convert JSON string to JavaScript object
function convertJsonToJs() {
    const jsonInput = document.getElementById('jsonInput').value; // Get the JSON string from textarea
    try {
        const jsObject = JSON.parse(jsonInput); // Parse the JSON string into a JavaScript object
        document.getElementById('jsObjectOutput').textContent = JSON.stringify(jsObject, null, 2); // Display the JavaScript object
    } catch (error) {
        alert('Invalid JSON format. Please check your input.'); // Alert if JSON is invalid
        console.error('Error parsing JSON:', error);
    }
}

// Attach event listeners to buttons
document.getElementById('loadJsonBtn').addEventListener('click', loadMusicData);
document.getElementById('convertToJsonBtn').addEventListener('click', convertToJson);
document.getElementById('jsonToJsBtn').addEventListener('click', convertJsonToJs);
