package com.infopine.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.infopine.Model.Student_details;
import com.infopine.Service.Student_Service;

@Controller
public class Student_Controller {
	@Autowired
	private Student_details sd;
	
	@Autowired
	private Student_Service ss;
@RequestMapping("/submit") //insertion
public void insert(HttpServletRequest req, HttpServletResponse res) {
	int id = Integer.parseInt(req.getParameter("id"));
	String name = req.getParameter("name");
	String branch = req.getParameter("branch");
	sd.setID(id);
	sd.setName(name);
	sd.setBranch(branch);
	
	ss.insert(sd);
	try {
        res.sendRedirect("index.jsp"); // Redirect to index page after update
    } catch (IOException e) {
        e.printStackTrace();
    }
	
    
}

@RequestMapping("/delete") //deletion 
public void delete(HttpServletRequest req, HttpServletResponse res) {
	int id = Integer.parseInt(req.getParameter("id"));
	ss.delete(id);
	try {
        res.sendRedirect("index.jsp"); // Redirect to index page after update
    } catch (IOException e) {
        e.printStackTrace();
    }
}

@RequestMapping("/display") // Display all the records
public void display(HttpServletRequest req, HttpServletResponse res) {
    List<Student_details> students = ss.getAllStudents(); // Get the list of students
    req.setAttribute("students", students); // Set the student list as a request attribute
    
    try {
        req.getRequestDispatcher("display.jsp").forward(req, res); // Forward to display.jsp
    } catch (Exception e) {
        e.printStackTrace();
    }
}
@RequestMapping("/update") // update
public void edit(HttpServletRequest req, HttpServletResponse res) {
    int id = Integer.parseInt(req.getParameter("id"));
    String newName = req.getParameter("name");
    String newBranch = req.getParameter("branch");
    
    // Set the new details for the student
    sd.setID(id); // Reference ID for update
    sd.setName(newName);
    sd.setBranch(newBranch);
    
    ss.update(sd); // Call the service to update the record
    
    try {
        res.sendRedirect("index.jsp"); 
    } catch (IOException e) {
        e.printStackTrace();
    }
}

}
/*
 * @RequestMapping("/delete") // Deletion public void delete(HttpServletRequest
 * req, HttpServletResponse res) { int id =
 * Integer.parseInt(req.getParameter("id")); boolean deleted = ss.delete(id); //
 * Assuming delete method returns a boolean
 * 
 * if (deleted) { // Optionally set a success message
 * req.setAttribute("message", "Record deleted successfully."); } else { // Set
 * an error message for non-existing record req.setAttribute("errorMessage",
 * "Record with ID " + id + " does not exist."); }
 * 
 * try { req.getRequestDispatcher("index.jsp").forward(req, res); // Redirect to
 * index.jsp } catch (Exception e) { e.printStackTrace(); } }
 */

