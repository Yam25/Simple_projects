package com.infopine.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.infopine.Model.Student_details;
import com.infopine.Service.Student_Service;

@Controller
public class Student_Controller {
	@Autowired
	private Student_details sd;
	
	@Autowired
	private Student_Service ss;
	
@RequestMapping("/submit") //insertion
public void insert(HttpServletRequest req, HttpServletResponse res) {
	int id = Integer.parseInt(req.getParameter("id"));
	String name = req.getParameter("name");
	String branch = req.getParameter("branch");
	sd.setID(id);
	sd.setName(name);
	sd.setBranch(branch);
	
	ss.insert(sd);
	try {
        res.sendRedirect("Message.jsp"); // Redirect to index page after insert
    } catch (IOException e) {
        e.printStackTrace();
    }
	
    
}

@RequestMapping("/delete") //deletion 
public void delete(HttpServletRequest req, HttpServletResponse res) throws IOException {
	int id = Integer.parseInt(req.getParameter("id"));

		ss.delete(id);
	try {
        res.sendRedirect("Message.jsp"); // Redirect to index page after update
    } catch (IOException e) {
        e.printStackTrace();
    }
}

//update
@RequestMapping("/update")
public void edit(HttpServletRequest req, HttpServletResponse res) {
    int id = Integer.parseInt(req.getParameter("id"));
    String newName = req.getParameter("name");
    String newBranch = req.getParameter("branch");
    
    // Set the new details for the student
    sd.setID(id); // Reference ID for update
    sd.setName(newName);
    sd.setBranch(newBranch);
    
    ss.update(sd); // Call the service to update the record
    
    try {
        res.sendRedirect("Message.jsp");  //redirect after update
    } catch (IOException e) {
        e.printStackTrace();
    }
}
//display on console
/*
 * @RequestMapping("/students") public void findAll(HttpServletRequest req,
 * HttpServletResponse res) { ss.findAll(); try {
 * res.sendRedirect("display.jsp"); } catch (IOException e) {
 * e.printStackTrace(); } }
 */
@RequestMapping("/students")
public void findAll(HttpServletRequest req, HttpServletResponse res) {
	List<Student_details> std = ss.findAll();
	req.setAttribute("students", std);
	RequestDispatcher dispatcher = req.getRequestDispatcher("display.jsp");
	try {
		dispatcher.forward(req, res);
	}catch (ServletException | IOException e) {
		e.printStackTrace();
	}
}
}

