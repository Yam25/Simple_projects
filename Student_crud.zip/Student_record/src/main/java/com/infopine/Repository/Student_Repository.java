package com.infopine.Repository;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.infopine.Model.Student_details;
@Repository
public class Student_Repository {
    //insert
	public void insert(Student_details sd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		session.save(sd);
		t.commit();
		session.close();
	}
    //delete
	public void delete(int id) {
		    Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
		    SessionFactory sf = cfg.buildSessionFactory();
		    Session session = sf.openSession();
		    Transaction t = session.beginTransaction();
		    
		    // Fetch the existing student record
		    Student_details sd = session.get(Student_details.class, id); 
		    if (sd != null) {
		        session.delete(sd); // Delete the record if found
		    }
		    t.commit();
		    session.close();
		}
	//display
	public List<Student_details> findAll() {
        Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        List<Student_details> students = null;
        Transaction t = session.beginTransaction();
        Query<Student_details> query = session.createQuery("FROM Student_details", Student_details.class);
        
        students = query.list(); // Retrieve all students
        t.commit();
        session.close();
        return students;
    }
	public void update(Student_details sd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Student_details.class);
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();
       
        session.update(sd); // Update the record with new details

        t.commit();
        session.close();
    }

		
	}
		
	

