package com.infopine.Service;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infopine.Model.Faculty_details;
import com.infopine.Repository.Fac_Repository;

@Service
public class Fac_Service {

	@Autowired
	private Fac_Repository repo;

	public boolean insert(@Valid Faculty_details sd) {
		boolean res = repo.insert(sd);
		return res;
	}

	public boolean delete(int fid) {
		boolean res = repo.delete(fid);
		return res;
	}

	public boolean update(Faculty_details fd) {
		boolean res = repo.update(fd);
		return res;
	}


	public List<Faculty_details> findAll() {
		return repo.findAll();

	}
}