package com.infopine.Repository;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import com.infopine.Model.Faculty_details;

@Repository
public class Fac_Repository {
	// insert
	public boolean insert(Faculty_details fd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Faculty_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		try {

			session.save(fd);
			t.commit();
			System.out.println("Record added successfully");
			return true;

		} catch (Exception e) {

			e.printStackTrace();
			return false;

		} finally {
			if (session != null) {
				session.close();
				;
			}
		}
	}

	// delete
	public boolean delete(int fid) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Faculty_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		try {
			Faculty_details fd = session.get(Faculty_details.class, fid);

			if (fd != null) {
				session.delete(fd);
				t.commit();
				System.out.println("Record deleted Successfully");
				return true;
			}
		} catch (Exception e) {

			e.printStackTrace();
			return false;
		} finally {
			if (session != null) {
				session.close();
				;
			}
		}
		return false;

	}

	// update
	public boolean update(Faculty_details fd) {
		Configuration cfg = new Configuration().configure().addAnnotatedClass(Faculty_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		try {
			session.update(fd);
			t.commit();
			System.out.println("Record updated Successfully");
			return true;
		} catch (Exception e) {

			e.printStackTrace();
			return false;
		} finally {
			if (session != null) {
				session.close();
			}

		}
	}

	public List<Faculty_details> findAll() {

		Configuration cfg = new Configuration().configure().addAnnotatedClass(Faculty_details.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		String hql = "FROM Faculty_details";
		Query<Faculty_details> query = session.createQuery(hql);
		List<Faculty_details> results = query.list();
		t.commit();
		session.close();
		return results;
	}
}
