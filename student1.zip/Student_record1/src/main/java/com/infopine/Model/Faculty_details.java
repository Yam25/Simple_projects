package com.infopine.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Faculty_details {
	@Id
	private int fid;

	@NotNull
	@Pattern(regexp = "^[a-zA-Z\\s]+$")
	private String fname;

	@NotNull
	@Pattern(regexp = "^[a-zA-Z\\s]+$")
	private String branch;

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
}
