package com.infopine.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;

@Entity // used to create the table
@Component
public class Student_details {
	@Id
	private int id;

	/*
	 * @NotNull
	 * 
	 * @Pattern(regexp = "^[a-zA-Z\\s]+$")
	 */
	@NotBlank(message = "Name is required.")
	@Pattern(regexp = "^[a-zA-Z ]+$", message = "Name can only contain letters and spaces.")
	private String name;

	@NotBlank(message = "Name is required.")
	@Pattern(regexp = "^[a-zA-Z ]+$", message = "Name can only contain letters and spaces.")
	private String branch;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
}
