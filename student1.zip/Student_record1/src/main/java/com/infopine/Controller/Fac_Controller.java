package com.infopine.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.infopine.Model.Faculty_details;
import com.infopine.Service.Fac_Service;

@Controller
public class Fac_Controller {

	@Autowired
	private Faculty_details fd;

	@Autowired
	private Fac_Service fs;

	@PostMapping("/submit1")
	public String insert(@Valid @ModelAttribute("fd") Faculty_details fd, Model model) {

		boolean res = fs.insert(fd);

		if (res) {
			model.addAttribute("message1", "Faculty added successfully!");
			return "Message1.jsp";
		} else {
			model.addAttribute("error1", "Failed to add the Faculty! Please check your inputs. ");
			return "Error1.jsp";
		}
	}

	@PostMapping("/delete1") // delete
	public String delete(@RequestParam("fid") int fid, Model model) {

		boolean res = fs.delete(fid);
		if (res) {
			model.addAttribute("message1", "Faculty deleted successfully!");
			return "Message1.jsp";
		} else {
			model.addAttribute("error1", "Failed to delete the Faculty! Please check your input");
			return "Error1.jsp";

		}
	}

	@PostMapping("/update1") // update
	public String edit(@RequestParam("fid") int id, @RequestParam("fname") String newName,
			@RequestParam("branch") String newBranch, Model model) {
		fd.setFid(id);
		fd.setFname(newName);
		fd.setBranch(newBranch);
		boolean res = fs.update(fd);
		if (res) {
			model.addAttribute("message1", "Faculty updated successfully!");
			return "Message1.jsp";
		} else {
			model.addAttribute("error1", "Failed to update the Faculty! Please check your inputs.");
			return "Error1.jsp";
		}
	}

	@GetMapping("/faculty")
	public ModelAndView findAll() {
		List<Faculty_details> faculty = fs.findAll();
		System.out.println("Number of faculty fetched: " + (faculty != null ? faculty.size() : "null"));

		ModelAndView modelAndView = new ModelAndView("display1.jsp");

		modelAndView.addObject("faculty", faculty);

		return modelAndView;
	}
}
