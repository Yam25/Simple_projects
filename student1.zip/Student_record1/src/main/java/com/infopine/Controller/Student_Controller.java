package com.infopine.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infopine.Model.Student_details;
import com.infopine.Service.Student_Service;

@Controller
public class Student_Controller {

	@Autowired
	private Student_details sd;

	@Autowired
	private Student_Service ss;

	@PostMapping("/submit")
	public String insert(@ModelAttribute("sd") Student_details sd, Model model) {

		boolean res = ss.insert(sd);

		if (res) {
			model.addAttribute("message", "Student added successfully!");
			return "Message.jsp"; // Redirect to success message
		} else {
			model.addAttribute("error", "Failed to add the student! Please check your input. ");
			return "Error.jsp"; // Redirect to error page
		}
	}

	@PostMapping("/delete") // delete
	public String delete(@RequestParam("id") String id, Model model) {

		String regex = "\\d+";

		// Validate input
		if (id == null || id.trim().isEmpty()) {
			model.addAttribute("idError", "Student ID is required!");
			return "delete.jsp";
		}

		else if (!id.matches(regex)) {
			model.addAttribute("idError", "Student ID should be a number!");
			return "delete.jsp";
		}

		int studentId = Integer.parseInt(id);
		boolean res = ss.delete(studentId);

		if (res) {
			model.addAttribute("message", "Student deleted successfully!");
			return "Message.jsp";
		} else {
			model.addAttribute("error", "Failed to delete the student! Please check your input.");
			return "Error.jsp";
		}
	}

	@PostMapping("/update") // update
	public String edit(@RequestParam("id") int id, @RequestParam("name") String newName,
			@RequestParam("branch") String newBranch, Model model) {
		sd.setId(id);
		sd.setName(newName);
		sd.setBranch(newBranch);
		boolean res = ss.update(sd);
		if (res) {
			model.addAttribute("message", "Student updated successfully!");
			return "Message.jsp";
		} else {
			model.addAttribute("error", "Failed to update the student! Please check your input.");
			return "Error.jsp";
		}
	}

	@GetMapping("/students")
	public String findAll(Model model) {

		List<Student_details> students = ss.findAll();
		System.out.println("Number of students fetched: " + (students != null ? students.size() : "null"));
		model.addAttribute("students", students); // Use model to pass data
		// model.addAttribute("message", "Student records displayed successfully!");
		return "display.jsp";
	}
}
